package Projeto.partePOO;

public class Jogos extends Midias {
    public Jogos() {
        super();
    }
}
