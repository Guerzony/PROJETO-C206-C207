package Projeto.partePOO;

public class Filmes extends Midias {

    public Filmes() {
        super();
    }
}
